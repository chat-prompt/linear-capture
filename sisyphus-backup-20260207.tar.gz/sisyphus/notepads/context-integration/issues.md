# Issues & Gotchas

This file tracks problems encountered and their solutions.

---
