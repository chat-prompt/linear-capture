# Issues & Gotchas - User Hint Feature

## Problems Encountered

(Subagents will append issues here)
