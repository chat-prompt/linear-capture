# Linear Capture 검색 편중 문제 분석 및 개선안

## 현재 상황 요약

### 배경
- **기존 계획**: `search-quality-improvement.md` (5 Task, 검색 품질 50%+ 향상 목표)
- **새 발견**: Worktree 작업 중 소스 간 편중 문제 발견
- **핵심 질문**: 기존 계획대로 진행 vs 편중 문제 먼저 해결

---

## 현재 검색 아키텍처

```
Query 입력
    ↓
┌─────────────────────────────────────────────────────────┐
│ 1. 전처리 (text-preprocessor.ts)                       │
│    - URL 정규화, 이모지 제거, 마크다운 정리             │
└─────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────┐
│ 2. 하이브리드 검색 (local-search.ts)                   │
│    ├── Semantic Search: pgvector 코사인 유사도         │
│    └── Keyword Search: PostgreSQL FTS (tsvector)       │
└─────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────┐
│ 3. RRF 병합 (Reciprocal Rank Fusion, k=60)            │
│    - Keyword-only 결과 → 0.3 고정 점수 (문제!)         │
└─────────────────────────────────────────────────────────┘
    ↓
  최종 결과 반환
```

### 미구현 항목 (기존 계획)
- `recency-boost.ts` - 14일 반감기 지수 감쇠
- `text-chunker.ts` - 슬라이딩 윈도우 청킹
- `reranker.ts` - Cohere Rerank API 연동
- Worker `/rerank` 엔드포인트

---

## 발견된 편중 문제

### 1. Slack 검색/동기화 일관성 불일치 🔴

| 동작 | Slack Sync | Slack Search |
|------|-----------|--------------|
| 채널 미선택 시 | ✅ 전체 public 채널 동기화 | ❌ **Slack 완전 제외** |

**문제 위치**:
```typescript
// local-search.ts - semanticSearch(), keywordSearch(), likeSearch() 모두 동일
const selectedChannels = getSelectedSlackChannels();
if (selectedChannels.length > 0) {
  // 선택된 채널만 검색
} else {
  conditions.push(`source_type != 'slack'`);  // ⚠️ Slack 완전 제외
}
```

**영향**: 사용자가 채널을 선택하지 않으면 동기화된 Slack 데이터가 검색 결과에 나타나지 않음.

---

### 2. Keyword-only 0.3 패널티 🔴

**문제 위치**:
```typescript
// local-search.ts line 443-446
keyword.forEach((result, index) => {
  // ...
  if (!resultMap.has(result.id)) {
    semanticScores.set(result.id, 0.3); // ⚠️ 하드코딩된 낮은 점수
  }
});
```

**영향**: 
- Semantic 검색에서 안 나오고 Keyword에서만 매칭된 결과 = 0.3 고정 점수
- 짧은 Slack 메시지는 semantic 매칭이 약해서 keyword-only가 많음
- → **Slack이 체계적으로 불리**

**추가 위험**:
- 계획된 `applyRecencyBoost()`가 이 0.3을 "낮은 품질"로 해석
- → RecencyBoost를 적용해도 Slack이 여전히 불리

---

### 3. FTS Title 가중치 불균형 🟡

**문제 위치**:
```sql
-- database.ts line 137-139
tsv tsvector GENERATED ALWAYS AS (
  setweight(to_tsvector('simple', coalesce(title, '')), 'A') ||  -- Title: 높은 가중치
  setweight(to_tsvector('simple', content), 'B')                 -- Content: 낮은 가중치
) STORED
```

**소스별 Title 특성**:

| 소스 | Title 형태 | FTS 'A' 가중치 혜택 |
|------|-----------|:------------------:|
| Notion | 페이지 제목 (의미 있음) | ✅ 높음 |
| Linear | 이슈 제목 (의미 있음) | ✅ 높음 |
| Slack | `#채널명 - 사용자명` (자동 생성) | ❌ 낮음 |
| Gmail | 이메일 제목 (의미 있음) | ✅ 높음 |

**Slack Title 생성 위치**:
```typescript
// slack-sync.ts ~line 405
title: `#${channelName} - ${userName}`  // 검색 키워드 매칭 어려움
```

---

### 4. 문서 길이 & Semantic 검색 편향 🟡

| 소스 | 문서 특성 | Semantic 영향 |
|------|----------|---------------|
| Notion | 긴 문서 (5000자 제한) | 임베딩이 평균화 → 특정 키워드 매칭 약해짐 |
| Slack | 짧은 메시지 | 임베딩 밀도 높음 → 키워드 매칭 강함 |

**역설**: 짧은 Slack 메시지가 semantic에서 강할 수 있지만, keyword-only 0.3 패널티로 상쇄됨.

---

### 5. 짧은 쿼리 (≤3자) 편향 🟡

**문제 위치**:
```typescript
// local-search.ts line 314-316
if (query.length <= 3) {
  console.log(`[LocalSearch] Short query "${query}" - using LIKE search`);
  return this.likeSearch(query, limit, source);
}

// likeSearch() line 411
ORDER BY source_created_at DESC  // ⚠️ 관련성 무관, 최신순만
```

**영향**: 3자 이하 검색어 → 100% 최신 문서 우선 → Slack 유리 (실시간 특성)

---

### 6. 계획된 기능의 편중 영향

| 계획된 기능 | 예상 영향 | 설명 |
|------------|:--------:|------|
| RecencyBoost (14일) | Slack ↑ | 최신 메시지가 많은 Slack에 유리 |
| Reranker (Cohere) | Notion/Linear ↑ | 긴 문서 + 풍부한 컨텍스트 선호 |
| Chunking | 중립화 | 문서 길이 정규화로 공정성 개선 |

**위험**: RecencyBoost와 Reranker가 서로 반대 방향으로 작용 → 예측 불가능한 결과

---

## 편중 흐름도

```
검색 쿼리 입력
     ↓
┌─────────────────────────────────────────────────────────┐
│ Stage 1: Slack 채널 미선택 → Slack 완전 제외 🔴        │
└─────────────────────────────────────────────────────────┘
     ↓
┌─────────────────────────────────────────────────────────┐
│ Stage 2: Semantic Search                               │
│   - 긴 문서(Notion): 평균화된 임베딩 → 특정 매칭 약함   │
│   - 짧은 메시지(Slack): 밀도 높은 임베딩 → 매칭 강함    │
└─────────────────────────────────────────────────────────┘
     ↓
┌─────────────────────────────────────────────────────────┐
│ Stage 3: Keyword Search (FTS)                          │
│   - Title 'A' 가중치: Notion/Linear 유리 🟡            │
│   - Slack 제목은 "#채널-사용자" → 매칭 어려움           │
└─────────────────────────────────────────────────────────┘
     ↓
┌─────────────────────────────────────────────────────────┐
│ Stage 4: RRF 병합                                      │
│   - Keyword-only 결과 → 0.3 고정 점수 🔴               │
│   - Slack이 체계적으로 불이익                          │
└─────────────────────────────────────────────────────────┘
     ↓
┌─────────────────────────────────────────────────────────┐
│ Stage 5 (계획): Reranker                               │
│   - 긴 문서 선호 → Notion/Linear 유리                  │
└─────────────────────────────────────────────────────────┘
     ↓
┌─────────────────────────────────────────────────────────┐
│ Stage 6 (계획): RecencyBoost                           │
│   - 14일 반감기 → 최신 Slack 유리                      │
└─────────────────────────────────────────────────────────┘
     ↓
  최종 결과 (어느 단계가 지배하느냐에 따라 결과 달라짐)
```

---

## Oracle 아키텍처 상담 결과

### 핵심 권고

> **"기존 계획대로 Reranker + RecencyBoost를 추가하면, 현재 숨겨진 편중(0.3 패널티, Slack 제외)이 증폭되어 나중에 디버깅/튜닝이 더 어려워짐"**

### 권장 접근법: Option B

기존 계획을 진행하되, **"편중 수정 레이어"를 먼저 추가**

---

## 개선안

### Wave 0: 편중 기초 수정 (새로 추가, ~4시간)

#### Task 0-A: Slack 검색/동기화 일관성 수정 (1시간)

**현재 문제**:
- Sync: 채널 미선택 → 전체 public 채널 동기화
- Search: 채널 미선택 → Slack 완전 제외

**해결 방안** (둘 중 하나 선택):
1. **Option 1 (Sync 따라가기)**: Search도 채널 미선택 시 전체 Slack 포함
2. **Option 2 (Search 따라가기)**: Sync도 선택된 채널만 동기화

**권장**: Option 1 - 사용자가 동기화한 데이터는 검색 가능해야 함

**수정 위치**: `local-search.ts` - `semanticSearch()`, `keywordSearch()`, `likeSearch()`

---

#### Task 0-B: 0.3 하드코딩 제거 (30분)

**현재 코드**:
```typescript
// local-search.ts line 445
semanticScores.set(result.id, 0.3);
```

**해결 방안**:
```typescript
// RRF 점수를 정규화하여 사용
const normalizedRRF = rrfScores.get(result.id)! / maxRRFScore;
semanticScores.set(result.id, normalizedRRF);
```

또는 keyword 결과의 `ts_rank_cd` 값을 정규화하여 사용.

---

#### Task 0-C: 소스별 균형 후보 검색 (1시간)

**현재**: 각 채널에서 상위 100개 전체 검색 → 긴 문서가 많으면 Slack 밀림

**해결**:
```typescript
// 각 소스별 40개씩 균등 검색
const RETRIEVAL_PER_SOURCE = 40;
const sources = ['notion', 'slack', 'linear', 'gmail'];

// 소스별로 검색 후 병합
const semanticBySource = await Promise.all(
  sources.map(s => this.semanticSearch(queryEmbedding, RETRIEVAL_PER_SOURCE, s))
);
```

---

#### Task 0-D: Slack 인덱싱 시 Title 처리 (1시간)

**현재**:
```typescript
// slack-sync.ts
title: `#${channelName} - ${userName}`  // FTS 'A' 가중치를 비효과적으로 사용
```

**해결 방안** (둘 중 하나):
1. **Option 1**: `title: null` → FTS에서 title 가중치 무시
2. **Option 2**: `title: message.text.substring(0, 100)` → 메시지 첫 100자를 제목으로

**권장**: Option 2 - 메시지 내용이 제목 검색에 반영됨

**메타데이터로 이동**: `channelName`, `userName`은 metadata에 저장 (현재도 이미 있음)

---

### Wave 1-3: 기존 계획 유지

| Wave | Task | 내용 |
|:----:|:----:|------|
| 1 | 1 | Worker: `toUpperCase()` 제거 + 절단 2000자 확대 |
| 1 | 2 | `recency-boost.ts` 생성 (14일 반감기) |
| 2 | 3 | `text-chunker.ts` + Sync Adapter 청킹 적용 |
| 2 | 4 | Worker `/rerank` 엔드포인트 + `reranker.ts` |
| 3 | 5 | `local-search.ts`에 통합 + **바이어스 로깅 추가** |

---

### 추가 권장: 바이어스 관찰 로깅

Task 5에 추가:

```typescript
// search() 함수 끝에 추가
const logBiasDistribution = (stage: string, results: SearchResult[]) => {
  const distribution = results.reduce((acc, r) => {
    acc[r.source] = (acc[r.source] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  console.log(`[Bias:${stage}]`, distribution);
};

logBiasDistribution('semantic-top10', semanticResults.slice(0, 10));
logBiasDistribution('keyword-top10', keywordResults.slice(0, 10));
logBiasDistribution('rrf-top10', merged.slice(0, 10));
logBiasDistribution('final-top10', boosted.slice(0, 10));
```

---

## 수정된 실행 계획 요약

```
Wave 0 (NEW - 4시간)
├── Task 0-A: Slack 검색/동기화 일관성
├── Task 0-B: 0.3 패널티 제거
├── Task 0-C: 소스별 균형 후보 검색
└── Task 0-D: Slack title 처리 개선

Wave 1 (기존)
├── Task 1: Worker 수정
└── Task 2: RecencyBoost

Wave 2 (기존)
├── Task 3: Chunking
└── Task 4: Reranker

Wave 3 (기존 + 확장)
└── Task 5: 통합 + 바이어스 로깅
```

**총 예상 시간**: 기존 2일 + 4시간 = ~2.5일

---

## 외부 솔루션 검토 결과

| 솔루션 | 편중 해결? | 비고 |
|--------|:---------:|------|
| Elasticsearch | ❌ | 검색 품질 ↑, 편중은 직접 구현 |
| Meilisearch | ❌ | 동일 |
| Cohere Rerank | ⚠️ 부분 | 품질 ↑, 긴 문서 선호 문제 그대로 |
| LangChain | ❌ | 추상화만 제공 |

**결론**: "소스별 공정성"은 **비즈니스 로직** → 어떤 도구를 써도 직접 구현 필요

---

## 다음 단계

1. 이 문서 검토
2. Wave 0 먼저 진행할지, 기존 계획 먼저 진행할지 결정
3. 계획 확정 후 `/start-work` 실행

---

*최종 업데이트: 2025-02-06*
*분석 참여: Oracle (아키텍처 상담)*
