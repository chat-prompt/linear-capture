# Draft: Slack Channel Selector UI Redesign

## Requirements (confirmed)

### Core Problem
- Slack 채널 선택기가 다른 integration(Notion, Gmail)에 비해 너무 많은 영역 차지
- 시각적 불균형으로 Settings UI 일관성 저해

### User Decisions
- **개선 방향**: 모달로 분리 (메인 UI에는 요약만)
- **메인 UI 표시**: 카운트만 ("12/45 channels")
- **모달 트리거**: [편집] 버튼
- **필수 기능**: 검색 필터링, 전체 선택/해제, 카운트 표시

### Target Channel Count
- 10-50개 (중규모 워크스페이스)

## Technical Decisions

### UI Structure (Before → After)

**Before:**
```
┌─ Slack ──────────────────────────────────┐
│ 🔗 Slack     Workspace    [Sync] [⋮]    │
├──────────────────────────────────────────┤
│ ▼ Channels              12/45 selected   │
│ ┌────────────────────────────────────┐   │
│ │ 🔍 Search...  [All] [None]         │   │
│ │ ☑ # general                        │   │
│ │ ... (200px 스크롤)                  │   │
│ └────────────────────────────────────┘   │
└──────────────────────────────────────────┘
```

**After:**
```
┌─ Slack ──────────────────────────────────┐
│ 🔗 Slack     Workspace    [Sync] [⋮]    │
│   📺 12/45 channels [편집]               │  ← 간결!
└──────────────────────────────────────────┘

(모달 열면)
┌─────────────────────────────────────────┐
│ Select Channels                    [×]  │
├─────────────────────────────────────────┤
│ 🔍 Search channels...                   │
│ [Select All] [Deselect All]    12/45   │
├─────────────────────────────────────────┤
│ ☑ # general                             │
│ ☑ # engineering                         │
│ ☐ # random                              │
│ ... (스크롤)                             │
├─────────────────────────────────────────┤
│                      [Cancel] [Save]    │
└─────────────────────────────────────────┘
```

### Implementation Approach
1. 기존 `#channelSelectionModal` 재활용 (이미 존재함)
2. 메인 `#slackChannelSelector` 영역을 inline summary로 대체
3. CSS 수정으로 레이아웃 조정
4. JavaScript 로직은 대부분 유지 (renderChannelList 재사용)

### Files to Modify
- `src/renderer/settings.html` - HTML 구조, CSS, JS 로직

## Research Findings

### Baymard UX Guidelines (Drop-down Usability)
- 10개 이상 옵션: autocomplete 또는 별도 선택 UI 권장
- 선택 항목을 명확히 표시해야 함
- 검색 필터 필수

### Mattermost Implementation
- 체크박스 리스트 + 검색
- Recommended 섹션 (최근 활동 기반)
- 모달 형태

### 기존 구현 분석
- `#channelSelectionModal` 이미 OAuth 후 사용 중
- `renderChannelList()` 함수 재사용 가능
- `selectedChannelIds` Set으로 상태 관리

## Scope Boundaries

### IN Scope
- Settings 페이지의 Slack 채널 선택기 UI 변경
- 메인 영역 → inline summary + 편집 버튼
- 모달에서 채널 선택 (기존 모달 재활용)
- CSS 스타일링 개선

### OUT of Scope
- IPC 핸들러 변경 (기존 로직 유지)
- electron-store 구조 변경 (기존 데이터 구조 유지)
- 다른 integration (Notion, Gmail) UI 변경
- 새로운 기능 추가 (그룹핑, 추천 등)

## Open Questions
- (없음 - 모두 확정됨)

## Test Strategy
- 수동 테스트: `npm run pack:clean`으로 패키징 후 테스트
- 테스트 시나리오:
  1. Slack 연결 상태에서 채널 요약 표시 확인
  2. [편집] 버튼 클릭 → 모달 열림
  3. 검색, 전체 선택/해제 동작
  4. 저장 → 메인 UI 카운트 업데이트
  5. OAuth 후 모달 동작 (기존 기능 유지)
